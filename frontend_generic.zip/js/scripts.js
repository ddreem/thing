$(document).ready(function(){
    // Slick Slider
    $('.games-slider').slick({
        centerMode: true,
        dots: false,
        infinite: true,
        speed: 300,
        autoplay: true,
        autoplaySpeed: 2000,
        slidesToShow: 5,
        slidesToScroll: 1,
        responsive: [{
        breakpoint: 1200,
        settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
        dots: true
        }
    },
    {
        breakpoint: 600,
        settings: {
        slidesToShow: 2,
        slidesToScroll: 1
        }
    },
    {
        breakpoint: 480,
        settings: {
        slidesToShow: 1,
        slidesToScroll: 1
        }
    }
    ]
    });


    // Mobile Menu
    $('.canvasOpen').click(function(){
        $('.canvas-menu').toggleClass('hide');
        return false;
    });
    $('.canvas-close a').click(function(){
        $('.canvas-menu').addClass('hide');
        return false;
    });
})

// Hide Table
const table = document.querySelectorAll('.hide-tb');

table.forEach(button => {
    button.addEventListener('click', function() {
        button.nextElementSibling.classList.toggle('hide');
        if (button.nextElementSibling.className === 'lg-table hide') {
            button.innerHTML = 'Show Table';
        } else {
            button.innerText = 'Hide Table';
        }
    });
});
 